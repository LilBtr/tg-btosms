from .text import vip
from .callback import vip
from .commands import vip
from .states import vip
from .admin_sending import vip
from .buttons import vip
from .service import vip
from .qiwi import vip
from .activate import vip

__all__ = ["vip"]
