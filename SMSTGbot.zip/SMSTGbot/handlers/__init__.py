from .errors import vip
from .admin import vip
from .user import vip

__all__ = ["vip"]
