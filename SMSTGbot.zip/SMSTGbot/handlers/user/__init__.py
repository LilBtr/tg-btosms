from .help import vip
from .start import vip
from .callback import vip
from .states import vip
from .text import vip

__all__ = ["vip"]
