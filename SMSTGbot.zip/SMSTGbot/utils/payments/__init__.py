from .btc import BTCPayment
from .qiwi import QiwiPay
