from .user_menu import main_menu, store_buttons
from .admin_menu import *
