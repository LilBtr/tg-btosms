from .admin_menu import admin_user_markup, admin_sending, admin_btn_markup, admin_service_markup, \
    admin_stats_markup, admin_qiwi_markup, adm_percent_markup
from .user_menu import *
